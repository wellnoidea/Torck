﻿/*
-	from: http://gotoandlearn.com/play.php?id=176
-	Registration Points of box2d objects are in the centre of the objects (not e.g. upper left)
-	"The box2d API might get a little to get used to"

-------------------

////////// FURTHER RESSOURCES: /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

SOUND:

http://cssdeck.com/labs/ping-pong-game-tutorial-with-html5-canvas-and-sounds



OTHER GAME TUTORIALS:

http://blog.sklambert.com/html5-canvas-game-panning-a-background/




*/
// Object definition giving box2d kind of a namespace and allowing shortened terms to access box2d functions
// May be used in a self executing anonymous function to get it off the global scope

// This code is so messed up, it's hard to bear without beer
// Good that I have one.
// .
// ..
// ...
// It's empty.
// .
// ..
// ...
// Aaaaand there's a new one.


// Canvas definition
var c=document.getElementById("canvas"); 
var ctx=c.getContext("2d");
ctx.fillStyle="#FF0000";
ctx.fillRect(0,0,150,75);

var box2d = {
	b2Vec2 : Box2D.Common.Math.b2Vec2,
	b2BodyDef : Box2D.Dynamics.b2BodyDef,
	b2Body : Box2D.Dynamics.b2Body,
	b2FixtureDef : Box2D.Dynamics.b2FixtureDef,
	b2Fixture : Box2D.Dynamics.b2Fixture,
	b2World : Box2D.Dynamics.b2World,
	b2MassData : Box2D.Collision.Shapes.b2MassData,
	b2PolygonShape : Box2D.Collision.Shapes.b2PolygonShape,
	b2CircleShape : Box2D.Collision.Shapes.b2CircleShape,
	b2DebugDraw : Box2D.Dynamics.b2DebugDraw,
	b2MouseJointDef :  Box2D.Dynamics.Joints.b2MouseJointDef,
	b2Shape : Box2D.Collision.Shapes.b2Shape,
	b2RevoluteJointDef : Box2D.Dynamics.Joints.b2RevoluteJointDef,
	b2Joint : Box2D.Dynamics.Joints.b2Joint,
	b2PrismaticJointDef : Box2D.Dynamics.Joints.b2PrismaticJointDef,
	b2ContactListener : Box2D.Dynamics.b2ContactListener,
	b2Settings : Box2D.Common.b2Settings,
	b2Mat22 : Box2D.Common.Math.b2Mat22,
	b2EdgeChainDef : Box2D.Collision.Shapes.b2EdgeChainDef,
	b2EdgeShape : Box2D.Collision.Shapes.b2EdgeShape,
	b2WorldManifold : Box2D.Collision.b2WorldManifold
};
/*
var b2Vec2 = Box2D.Common.Math.b2Vec2
	, b2AABB = Box2D.Collision.b2AABB
	, b2BodyDef = Box2D.Dynamics.b2BodyDef
	, b2Body = Box2D.Dynamics.b2Body
	, b2FixtureDef = Box2D.Dynamics.b2FixtureDef
	, b2Fixture = Box2D.Dynamics.b2Fixture
	, b2World = Box2D.Dynamics.b2World
	, b2MassData = Box2D.Collision.Shapes.b2MassData
	, b2PolygonShape = Box2D.Collision.Shapes.b2PolygonShape
	, b2CircleShape = Box2D.Collision.Shapes.b2CircleShape
	, b2DebugDraw = Box2D.Dynamics.b2DebugDraw
	, b2MouseJointDef =  Box2D.Dynamics.Joints.b2MouseJointDef
	, b2Shape = Box2D.Collision.Shapes.b2Shape
	, b2RevoluteJointDef = Box2D.Dynamics.Joints.b2RevoluteJointDef
	, b2Joint = Box2D.Dynamics.Joints.b2Joint
	, b2PrismaticJointDef = Box2D.Dynamics.Joints.b2PrismaticJointDef
	, b2ContactListener = Box2D.Dynamics.b2ContactListener
	, b2Settings = Box2D.Common.b2Settings
	, b2Mat22 = Box2D.Common.Math.b2Mat22
	, b2EdgeChainDef = Box2D.Collision.Shapes.b2EdgeChainDef
	, b2EdgeShape = Box2D.Collision.Shapes.b2EdgeShape
	, b2WorldManifold = Box2D.Collision.b2WorldManifold
	;*/


// box2d works in metres, the scale is used to calculate from metres to pixels, thus 1 m = 30 px
// Values given are in pixles thus / 400, value coming from box2d in metres thus * SCALE
var SCALE = 30;

// stage: the easeljs stage to be used
// world: the box2d world
// Defined on the global scope for referencing elsewhere this is for demonstration reasons only, normally better capsulated (?)
var stage, world, thingy, torck, debugDraw;
var aGroundThing = new Array(); // Better take an object in the long run
//var groundElements = new Array();
var offsetX = 0;
var offsetY = 0;
var i = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////// And Some Sound //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// The background music
// Script source: 		http://stackoverflow.com/questions/3273552/html-5-audio-looping
// Sound source: 		http://opengameart.org/content/weltherrscher
myAudio = document.getElementById("backgroundTheme"); 
myAudio.addEventListener('ended', function() {
    this.currentTime = 0;
    this.play();
}, false);
// myAudio.play(); // reenable for the background sound

// Initialise the collision sound
// Will be played on iteration of the collision counter
// Initial inspiration: http://cssdeck.com/labs/ping-pong-game-tutorial-with-html5-canvas-and-sounds
// Sound source:		http://www.pacdv.com/sounds/mechanical_sounds.html 			'Metal Button'
collision = document.getElementById("collide"); // reenable for the collision sound

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////// World Objects ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function aGroundII(imageID, isSquare, posX, posY, sizeX, sizeY, isDynamic, density, restitution, friction, filterCategory, filterMask) {

	this.sizeX = sizeX;
	this.sizeY = sizeY;

	// 	- Needs a fixture definition (densitiy, friction, restitution)
	// 	- And a body definition
	// Define the fixture
	var fixDef = new box2d.b2FixtureDef()
	// set properties
	fixDef.density = density;

	// Filterin for making objects pass by each other while others collide with each other
	// For filtering see: 				http://www.aurelienribon.com/blog/2011/07/box2d-tutorial-collision-filtering/
	// For bitwise operators see: 		https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Bitwise_Operators
	fixDef.filter.categoryBits = filterCategory;
	fixDef.filter.maskBits = filterMask;
	
	//	fixDef.name = 'Torck';
	fixDef.friction = friction;
	//fixDef.shape = new box2d.b2CircleShape(19 / SCALE);
	if (isSquare){
		fixDef.shape = new box2d.b2PolygonShape();
		fixDef.shape.SetAsBox(sizeX / SCALE, sizeY / SCALE);
	} else {
		fixDef.shape = new box2d.b2CircleShape(sizeX / SCALE);
		sizeY = sizeX;
	}
	// The 'bounciness' of an object
	fixDef.restitution = restitution;

	

	// Define the body
	// There are two types of objects static and dynamic, the first is fixed like the floor, the second are the movable objects
	var bodyDef = new box2d.b2BodyDef();
		// The ball is dynamic, of course
	if (isDynamic){
		bodyDef.type = box2d.b2Body.b2_dynamicBody;
	}else{
		bodyDef.type = box2d.b2Body.b2_staticBody;
	}
	bodyDef.position.x = posX / SCALE;	
	bodyDef.position.y = posY / SCALE;
	bodyDef.userData = 'ground';

	// create a body into the box2d world
	// Method chaining CreateBody() . CreateFixture() Yay!

	var b = world.CreateBody( bodyDef );
	var f = b.CreateFixture(fixDef);

	body = b;

	this.body = body;



	// draw is also (ab)used as do-per-tick function
	this.draw = function () {
		
		var x = (this.body.GetPosition().x) * SCALE + 500  - offsetX;
		var y = (this.body.GetPosition().y) * SCALE + 300  - offsetY;
	    var rotation = this.body.GetAngle();

	    ctx.save();
	    ctx.translate(x , y); // change origin
	    ctx.rotate(rotation);
		var img = document.getElementById(imageID);
		//*********************************************************************************************************************************************
		ctx.drawImage(img, -sizeX, -sizeY, 2 * sizeX, 2 * sizeY);
		ctx.restore();
		
	} 
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////// A WET Copy of aGroundII /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function aSensor(imageID, isSquare, posX, posY, sizeX, sizeY, isDynamic, density, restitution, friction, filterCategory, filterMask) {

	this.sizeX = sizeX;
	this.sizeY = sizeY;

	// 	- Needs a fixture definition (densitiy, friction, restitution)
	// 	- And a body definition
	// Define the fixture
	var fixDef = new box2d.b2FixtureDef()
	// set properties
	fixDef.density = density;

	// Filterin for making objects pass by each other while others collide with each other
	// For filtering see: 				http://www.aurelienribon.com/blog/2011/07/box2d-tutorial-collision-filtering/
	// For bitwise operators see: 		https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Bitwise_Operators
	fixDef.filter.categoryBits = filterCategory;
	fixDef.filter.maskBits = filterMask;
	fixDef.isSensor = true;;
	
	//	fixDef.name = 'Torck';
	fixDef.friction = friction;
	//fixDef.shape = new box2d.b2CircleShape(19 / SCALE);
	if (isSquare){
		fixDef.shape = new box2d.b2PolygonShape();
		fixDef.shape.SetAsBox(sizeX / SCALE, sizeY / SCALE);
	} else {
		fixDef.shape = new box2d.b2CircleShape(sizeX / SCALE);
		sizeY = sizeX;
	}
	// The 'bounciness' of an object
	fixDef.restitution = restitution;

	

	// Define the body
	// There are two types of objects static and dynamic, the first is fixed like the floor, the second are the movable objects
	var bodyDef = new box2d.b2BodyDef();
		// The ball is dynamic, of course
	if (isDynamic){
		bodyDef.type = box2d.b2Body.b2_dynamicBody;
	}else{
		bodyDef.type = box2d.b2Body.b2_staticBody;
	}
	bodyDef.position.x = posX / SCALE;	
	bodyDef.position.y = posY / SCALE;
	bodyDef.userData = 'sensor';
	bodyDef.linearDamping = 1000;

	// create a body into the box2d world
	// Method chaining CreateBody() . CreateFixture() Yay!

	var b = world.CreateBody( bodyDef );
	var f = b.CreateFixture(fixDef);

	body = b;

	this.body = body;



	// draw is also (ab)used as do-per-tick function
	this.draw = function () {
		
		var x = (this.body.GetPosition().x) * SCALE + 500  - offsetX;
		var y = (this.body.GetPosition().y) * SCALE + 300  - offsetY;
	    var rotation = this.body.GetAngle();

	    ctx.save();
	    ctx.translate(x , y); // change origin
	    ctx.rotate(rotation);
		var img = document.getElementById(imageID);
		//*********************************************************************************************************************************************
		ctx.drawImage(img, -sizeX, -sizeY, 2 * sizeX, 2 * sizeY);
		ctx.restore();
		
	} 
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////// The Init Function, Let's Get Things Started /////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function init() {
	// The easeljs world, containing the DOM reference to the canvas element
	stage = new createjs.Stage(document.getElementById("canvas"));
	// The physics world
	setupPhysics();



	// Lowest Ground
	aGroundThing[i++] = new aGroundII("eroded_wood", true, 2000, 600, 2000, 20, false, 1, 0, 1, 2, -1); 
	// Left wall
	aGroundThing[i++] = new aGroundII("eroded_wood", true, 10, 300, 10, 1000, false, 1, 0, 1, 2, -1); 
	//some blocks
//	aGroundThing[i++] = new aGroundII("eroded_wood", true, 2300, 500, 200, 7, false, 1, 0, 1); 
//	aGroundThing[i++] = new aGroundII("eroded_wood", true, 1000, 0, 50, 50, true, 1, 0, 1);
//	aGroundThing[i++] = new aGroundII("eroded_wood", true, 300, 50, 25, 25, true, 1, 0, 1);
//	aGroundThing[i++] = new aGroundII("eroded_wood", true, 300, -1000, 250, 10, true, 1, 0, 1); 
//	aGroundThing[i++] = new aGroundII("schaumstoff", true, 800, -1000, 50, 50, true, 0.1, 0.5, 1); 
//	aGroundThing[i++] = new aGroundII("concrete", true, 850, 0, 25, 25, true, 50, 0, 1); 
//	aGroundThing[i++] = new aGroundII("schaumstoff", true, 100, -2000, 25, 25, true, 0.1, 0.5, 1, 1); 
//	aGroundThing[i++] = new aGroundII("bloeder_ball", false, 555, 250, 20, 25, true, 0.1, 0.5, 1); 
	aGroundThing[i++] = new aGroundII("bloeder_ball", false, 600, 250, 25, 25, true, 0.1, 0.8, 1, 2, -1); 
	aGroundThing[i++] = new aSensor("bloeder_ball", false, 300, 0, 25, 25, true, 0.5, 0.05, 1000, 1, -1); 
	console.log(i);//#delendum
//	aGroundThing[i++] = new aGroundII("eis", true, 750, 250, 75, 3, true, 1, 0, 0.002); 

// Since it's the player torck gets his own definition
// Singleton style
	torck = new aBall;

	var x = function () {
			// 	- Needs a fixture definition (densitiy, friction, restitution)
			// 	- And a body definition
			// Define the fixture
			var fixDef = new box2d.b2FixtureDef()
			// set properties
			fixDef.density = 0.1;
			fixDef.friction = 0.2;
			fixDef.shape = new box2d.b2CircleShape(21 / SCALE);
			// The 'bounciness' of an object
			fixDef.restitution = i / 10;

			// Define the body
			// There are two types of objects static and dynamic, the first is fixed like the floor, the second are the movable objects
			var bodyDef = new box2d.b2BodyDef();
				// The ball is dynamic, of course
			bodyDef.type = box2d.b2Body.b2_dynamicBody;
			bodyDef.position.x = 550 / SCALE;	
			bodyDef.position.y = 400 / SCALE;

			// create a body into the box2d world
			// Method chaining CreateBody() . CreateFixture() Yay!
			world.CreateBody(bodyDef).CreateFixture(fixDef);
		}


	//The tick function provided by easeljs
	// Lookin for a global function called tick on the global scope
	createjs.Ticker.addListener(this)
	createjs.Ticker.setFPS(60);
	// Boolean property for request animation frame in easeljs. Yay!
	createjs.Ticker.useRAF = true;

	var listener = new Box2D.Dynamics.b2ContactListener;
    listener.BeginContact = function(contact) {
    	if ((contact.GetFixtureA().GetBody().m_userData === 'torck' && contact.GetFixtureB().GetBody().m_userData === 'ground') ||
			(contact.GetFixtureA().GetBody().m_userData === 'ground' && contact.GetFixtureB().GetBody().m_userData === 'torck')) {
    		torck.contacts++;
    		console.log(torck.contacts);//#delendum
			collision.currentTime = 0.07;
			// collision.play(); // Reenable to get the collision sound
    	}
    	if (contact.GetFixtureA().GetBody().m_userData === 'sensor' || contact.GetFixtureB().GetBody().m_userData === 'sensor') {
    	    console.log('SENSOR ON!!!!!');//#delendum
    	}
    }

    listener.EndContact = function(contact) {
        if ((contact.GetFixtureA().GetBody().m_userData === 'torck' && contact.GetFixtureB().GetBody().m_userData === 'ground') ||
			(contact.GetFixtureA().GetBody().m_userData === 'ground' && contact.GetFixtureB().GetBody().m_userData === 'torck')) {
    		torck.contacts--;
    	    console.log(torck.contacts);//#delendum
    	}
    	if (contact.GetFixtureA().GetBody().m_userData === 'sensor' || contact.GetFixtureB().GetBody().m_userData === 'sensor') {
    	    console.log('SENSOR OFF!!!!!');//#delendum
    	}
    }

    listener.PostSolve = function(contact, impulse) {
    	//
    }

    listener.PreSolve = function(contact, oldManifold) {
    	//
    }

    this.world.SetContactListener(listener);

}







////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////// Definition of Torck /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function aBall() {
	this.run = true;
	this.moveX = 0;
	this.moveY = 0;
	this.contacts = 0;



	// 	- Needs a fixture definition (densitiy, friction, restitution)
	// 	- And a body definition
	// Define the fixture
	var fixDef = new box2d.b2FixtureDef()
	// set properties
	fixDef.density = 2.3456;
//	fixDef.userData = 'Torck';
//	fixDef.name = 'Torck';
	fixDef.friction = 0.4;
	fixDef.shape = new box2d.b2CircleShape(19 / SCALE);
	// The 'bounciness' of an object
	fixDef.restitution = 0.0;

	

	// Define the body
	// There are two types of objects static and dynamic, the first is fixed like the floor, the second are the movable objects
	var bodyDef = new box2d.b2BodyDef();
		// The ball is dynamic, of course
	//bodyDef.type = box2d.b2Body.b2_dynamicBody;
	bodyDef.type = box2d.b2Body.b2_dynamicBody;
	bodyDef.position.x = 300 / SCALE;	
	bodyDef.position.y = 550 / SCALE;
	bodyDef.userData = 'torck';

	// create a body into the box2d world
	// Method chaining CreateBody() . CreateFixture() Yay!

	var b = world.CreateBody( bodyDef );
	var f = b.CreateFixture(fixDef);

	body = b;

	this.body = body;

	////////// Define the Sensor for Jumping ////////////////////////////////////////////////////////////////////////////////////////////////////////

	var SensorFixDef = new box2d.b2FixtureDef()
	SensorFixDef.density = 5.4321;
	SensorFixDef.friction = 1;
	SensorFixDef.shape = new box2d.b2CircleShape(30 / SCALE);
	SensorFixDef.restitution = 0.0;
	SensorFixDef.IsSensor = true;
	var sensorBodyDef = new box2d.b2BodyDef();
	sensorBodyDef.type = box2d.b2Body.b2_dynamicBody;
	sensorBodyDef.position.x = Math.random() * 800 / SCALE;	
	sensorBodyDef.position.y = 0 / SCALE;
	sensorBodyDef.userData = 'I\'m a sensor!'
//	var sb = world.CreateBody( sensorBodyDef );
//	var sf = sb.CreateFixture(SensorFixDef);
//	sensor = sb;
//	this.sensor = sensor;

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// draw is also (ab)used as do-per-tick function
	this.draw = function () {
	//	var x = this.body.GetPosition().x * SCALE;
	//	var y = this.body.GetPosition().y * SCALE;


		var x = this.body.GetPosition().x * SCALE - offsetX + 500;
		var y = this.body.GetPosition().y * SCALE - offsetY + 300;

		console.log(this.body.GetPosition().x - aGroundThing[3].body.GetPosition().x);//#delendum

		posXY = new box2d.b2Vec2(this.body.GetPosition().x, this.body.GetPosition().y);
		aGroundThing[3].body.SetPosition(posXY);


		this.body.GetLinearVelocity()


	    var rotation = this.body.GetAngle();

	    if (this.body.GetContactList() !== null) {
	    	force = new box2d.b2Vec2(0, -1 * 200);
	    	//this.body.ApplyImpulse(force, this.body.GetPosition());
	    };//#delendum}//#delendum

	    ctx.save();
	    ctx.translate(x, y); // change origin
	    ctx.rotate(rotation * 0.8);
		var img = document.getElementById("king");
		//******************************************************************************************************************************************
		ctx.drawImage(img, - 20, - 26, 40, 48);
		ctx.restore();

		offsetX = offsetX + (this.body.GetPosition().x * SCALE - offsetX) / 10;

		//This is so not good, but i wanted to get the skull lower
	//	offsetY = offsetY + 200;
		offsetY = offsetY +(this.body.GetPosition().y * SCALE - offsetY) / 10;

	//	offsetY = offsetY - 200;
		//offsetY = this.body.GetPosition().y;

		//console.log(offsetX + '   ' + (this.body.GetPosition().x * SCALE - offsetX));//#delendum
	} 

	this.move = function () {

		var vorzeichen = 0;
		if (this.body.GetLinearVelocity().x > 0){
			var vorzeichen = -1;
		}else{
			var vorzeichen = 1;
		}
		if (this.moveX !== 0)
		{
			force = new box2d.b2Vec2(-this.moveX * 100 , 0);
		//	if (this.body.GetLinearVelocity().y < 0.1 && this.body.GetLinearVelocity().y > -0.1 ){
				this.body.ApplyTorque(( - this.moveX * 80) - this.body.GetAngularVelocity() * 3  );
		//	}
			//this.body.ApplyForce(force, this.body.GetPosition());
			//this.body.GetPosition()
		}

		if (this.moveY !== 0){
			force = new box2d.b2Vec2(0, this.moveY * 35);


			//this.moveY = 0;
		//	if (this.body.GetLinearVelocity().y < 0.1 && this.body.GetLinearVelocity().y > -0.1 ){
			// I do not fully understand the contact list yet, but it stays on not null a bit too long, so I built the jump lock
			if (this.contacts > 0 && this.body.GetLinearVelocity().y > -15){
				this.body.ApplyImpulse(force, this.body.GetPosition());

			} else {
				
			}		

			if (this.run){
				this.run = false;
				// Main Log
				console.log('aGroundThing[3]'); console.log(aGroundThing[3]);//#delendum
				console.log(aGroundThing[3].body.GetPosition());//#delendum
				console.log(aGroundThing[3].body.GetPosition());//#delendum
				console.log(this.body);
				console.log(this.body.m_contactList);
	

	//			this.sensor.m_fixtureList.SetSensor();//#delendum

			}
		}
	}
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////// Definition of Static Objects ////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
function aGround(isDynamic, xPosition, yPosition, xSize, ySize,data, density, friction, restitution, angle) {
	// ------------------------------ Create ground ------------------------------
	// 	- Needs a fixture definition (densitiy, friction, restitution)
	// 	- And a body definition
	// Define the fixture
	var fixDef = new box2d.b2FixtureDef()
		// set properties
	fixDef.density = density;
	fixDef.friction = friction;
	fixDef.shape = new box2d.b2PolygonShape();
	// 400 is 400 px on either side of the centre
	fixDef.shape.SetAsBox(xSize / SCALE, ySize / SCALE);
	// The 'bounciness' of an object
	fixDef.restitution = restitution;

	// Define the body
	// There are two types of objects static and dynamic, the first is fixed like the floor, the second are the movable objects
	var bodyDef = new box2d.b2BodyDef();
		// The floor is static, of course
	if (isDynamic) {
		bodyDef.type = box2d.b2Body.b2_dynamicBody;
	} else {
		bodyDef.type = box2d.b2Body.b2_staticBody;
	}
	
	bodyDef.position.x = xPosition / SCALE;	
	bodyDef.position.y = yPosition / SCALE;
	bodyDef.angle = angle;
	bodyDef.userData = data;

/*
	var b = world.CreateBody(bodyDef);
	var f = b.CreateFixture(fixDef);
	body = b;
	this.body = body;
*//*

	// create a body into the box2d world
	// Method chaining CreateBody() . CreateFixture() Yay!
	// this.body = world.CreateBody(bodyDef).CreateFixture(fixDef);
	world.CreateBody(bodyDef).CreateFixture(fixDef);
}*/

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////// Movement Requests ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


$(document).keydown(function(e){
	switch(e.keyCode)
	{
	case 37:
		torck.moveX = 1;
		break;
	case 38:
		torck.moveY = -1;
		break;
	case 39:
		torck.moveX = -1;
		break;
	case 40:
		torck.moveY = -1;
		break;
	}
	return false;
});

$(document).keyup(function(e){
	switch(e.keyCode)
	{
	case 37:
		torck.moveX = 0;
		break;
	case 38:
		torck.moveY = 0;
		break;
	case 39:
		torck.moveX = 0;
		break;
	case 40:
		torck.moveY = 0;
		break;
	}
	return false;
});

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function thingy() {
	// 	- Needs a fixture definition (densitiy, friction, restitution)
		// 	- And a body definition
		// Define the fixture
		var fixDef = new box2d.b2FixtureDef()
		// set properties
		fixDef.density = 1;
		fixDef.friction = 1;
		fixDef.shape = new box2d.b2CircleShape((Math.random() * 50 + 10) / SCALE);
		// The 'bounciness' of an object
		fixDef.restitution = 0.9;

		// Define the body
		// There are two types of objects static and dynamic, the first is fixed like the floor, the second are the movable objects
		var bodyDef = new box2d.b2BodyDef();
			// The ball is dynamic, of course
		bodyDef.type = box2d.b2Body.b2_dynamicBody;
		bodyDef.position.x = Math.random() * 800 / SCALE;	
		bodyDef.position.y = 0 / SCALE;

		// create a body into the box2d world
		// Method chaining CreateBody() . CreateFixture() Yay!
		world.CreateBody(bodyDef).CreateFixture(fixDef);
}

function setupPhysics (){
	// b2World needs a vector (b2Vec2) for gravity which takes gravity on the x and the y axis
	// 		second property is for allowing sleeping bodies, here true
	world = new box2d.b2World( new box2d.b2Vec2(0, 50), true)

	// Setup debug draw
	var debugDraw = new box2d.b2DebugDraw();
	// Provide a canvas to draw in
	debugDraw.SetSprite(stage.canvas.getContext('2d'));
	debugDraw.SetDrawScale(SCALE);
	debugDraw.SetFillAlpha(0.5);

	console.log('setupPhysics');//#delendum
	console.log(stage.canvas.getContext('2d'));//#delendum
	console.log(debugDraw);//#delendum
	
	console.log(world);//#delendum

	// Set shapes and joints to be drawn
	debugDraw.SetFlags(box2d.b2DebugDraw.e_shapeBit | box2d.b2DebugDraw.e_jointBit);
	// Tell the physics world about the debug draw
	 world.SetDebugDraw(debugDraw);

	 console.log(world);//#delendum
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////// The Ticker //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// The tick function called from the Ticker property
function tick() {


	torck.move();
	
	// update the easeljs stage
	stage.update();

	drawBackground(); // ooohhhhh bad practice, not even an object!

	// Draw what's comin from the Debug
	world.DrawDebugData();
	// Increment or step our physics world forward
		// Time step here equal to the FPS
		// Velocity iterations, higher = more accurate but slower
		// Position Iterations, ~
	// How about a for heh?
	for (var key in aGroundThing) {
		aGroundThing[key].draw();
	}

	torck.draw();
	drawForeground();
	world.Step(1/60, 10, 10);
	world.ClearForces(); // ???

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function drawBackground(){

	// Mun
	var x = ((aGroundThing[1].body.GetPosition().x) * SCALE + 3000  - offsetX) * 0.2;
	var y = ((aGroundThing[1].body.GetPosition().y) * SCALE + 300  - offsetY) * 0.2;
	var img = document.getElementById('bloeder_ball');
	ctx.save();
	ctx.translate(x , y );
	ctx.drawImage(img, 50,  0, 50, 50);
	ctx.restore();
	
	// cloud
	var x = ((aGroundThing[1].body.GetPosition().x) * SCALE + 3000  - offsetX) * 0.5;
	var y = ((aGroundThing[1].body.GetPosition().y) * SCALE + 250  - offsetY) * 0.5;
	var img = document.getElementById('cloud');
	ctx.save();
	ctx.translate(x , y );
	ctx.drawImage(img, 50,  50);
	ctx.restore();
}

function drawForeground(){
	// cloud
	var x = ((aGroundThing[1].body.GetPosition().x) * SCALE + 2000  - offsetX) * 2;
	var y = ((aGroundThing[1].body.GetPosition().y) * SCALE + 280  - offsetY) * 2;
	var img = document.getElementById('cloud');
	ctx.save();
	ctx.translate(x , y );
	ctx.drawImage(img, 50,  50);
	ctx.restore();
}
